touch ./__sys.php
touch ./Redis.php
sleep 1 
cp ./__sys.el ~/.ac-php/tags-home-jim-ac-php-commom_php/tags_dir_jim/
