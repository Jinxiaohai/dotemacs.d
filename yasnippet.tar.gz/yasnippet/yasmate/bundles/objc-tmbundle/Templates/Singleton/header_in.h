//
//  ${TM_NEW_FILE_BASENAME}.h
//
//  Created by ${TM_FULLNAME} on ${TM_DATE}.
//  Copyright (c) ${TM_YEAR} ${TM_ORGANIZATION_NAME}. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ${TM_NEW_FILE_BASENAME} : NSObject
{
}
+ (${TM_NEW_FILE_BASENAME}*)sharedInstance;
@end
